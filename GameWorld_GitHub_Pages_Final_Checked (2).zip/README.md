# GameWorld GitHub Pages
این نسخه Static است و مستقیم روی GitHub Pages اجرا می‌شود.
فایل `index.html` را در ریشه repository قرار بده.
در GitHub: Settings → Pages → Deploy from a branch → main → /(root) → Save.
توجه: GitHub Pages بک‌اند/WebSocket اجرا نمی‌کند؛ این نسخه برای اجرای مستقیم و تست بازی‌هاست و Multiplayer واقعی نیاز به Backend جدا دارد.
